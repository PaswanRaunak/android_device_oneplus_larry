cmd_usr/include/asm/ioctl.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ioctl.h usr/include/asm/ioctl.h
