cmd_usr/include/asm/mman.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/mman.h usr/include/asm/mman.h
