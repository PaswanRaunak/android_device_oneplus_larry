cmd_usr/include/asm/swab.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/swab.h usr/include/asm/swab.h
