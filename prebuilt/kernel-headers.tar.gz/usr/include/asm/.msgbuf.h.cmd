cmd_usr/include/asm/msgbuf.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/msgbuf.h usr/include/asm/msgbuf.h
