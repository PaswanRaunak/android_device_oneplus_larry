cmd_usr/include/asm/errno.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/errno.h usr/include/asm/errno.h
