cmd_usr/include/asm/resource.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/resource.h usr/include/asm/resource.h
