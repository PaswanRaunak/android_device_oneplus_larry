cmd_usr/include/asm/termios.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/termios.h usr/include/asm/termios.h
