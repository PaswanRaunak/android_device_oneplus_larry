cmd_usr/include/asm/kvm_para.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/kvm_para.h usr/include/asm/kvm_para.h
