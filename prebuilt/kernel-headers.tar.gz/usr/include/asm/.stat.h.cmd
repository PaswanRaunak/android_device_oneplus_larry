cmd_usr/include/asm/stat.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/stat.h usr/include/asm/stat.h
