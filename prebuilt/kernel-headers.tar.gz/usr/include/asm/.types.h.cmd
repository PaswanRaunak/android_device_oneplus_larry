cmd_usr/include/asm/types.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/types.h usr/include/asm/types.h
