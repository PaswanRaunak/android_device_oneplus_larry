cmd_usr/include/asm/ioctls.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ioctls.h usr/include/asm/ioctls.h
