cmd_usr/include/asm/sockios.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/sockios.h usr/include/asm/sockios.h
