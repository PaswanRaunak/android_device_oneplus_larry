cmd_usr/include/asm/ipcbuf.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/ipcbuf.h usr/include/asm/ipcbuf.h
