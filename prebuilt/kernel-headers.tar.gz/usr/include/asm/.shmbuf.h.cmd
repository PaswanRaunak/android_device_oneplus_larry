cmd_usr/include/asm/shmbuf.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh arch/arm64/include/generated/uapi/asm/shmbuf.h usr/include/asm/shmbuf.h
