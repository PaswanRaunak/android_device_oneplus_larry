cmd_usr/include/sound/tlv.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/include/uapi/sound/tlv.h usr/include/sound/tlv.h
