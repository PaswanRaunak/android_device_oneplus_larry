cmd_usr/include/drm/drm.h := sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/scripts/headers_install.sh /home/ubuntu/penguinos/kernel/oneplus/sm6375/include/uapi/drm/drm.h usr/include/drm/drm.h
